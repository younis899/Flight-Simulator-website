// Elements
const btnDarkMode = document.getElementById("btnDarkMode");
const body = document.body;
const navLinks = document.querySelectorAll(".nav-links a");
const views = document.querySelectorAll(".view");
const loginModal = document.getElementById("loginModal");
const signupModal = document.getElementById("signupModal");
const btnLogin = document.getElementById("btnLogin");
const closeLogin = document.getElementById("closeLogin");
const closeSignup = document.getElementById("closeSignup");
const showSignup = document.getElementById("showSignup");

let currentView = "home";

// Dark mode toggle
btnDarkMode.addEventListener("click", () => {
  body.classList.toggle("dark");
  btnDarkMode.textContent = body.classList.contains("dark") ? "Light Mode" : "Dark Mode";
});

// Navigation links switching
navLinks.forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const view = link.dataset.view;
    if (!view) return;
    switchView(view);
  });
});

function switchView(viewName) {
  views.forEach(v => v.classList.remove("active"));
  document.getElementById(viewName).classList.add("active");
  currentView = viewName;
}

// Login modal open
btnLogin.addEventListener("click", () => {
  loginModal.style.display = "flex";
});

// Close modals
closeLogin.addEventListener("click", () => {
  loginModal.style.display = "none";
});
closeSignup.addEventListener("click", () => {
  signupModal.style.display = "none";
});

// Show signup from login
showSignup.addEventListener("click", (e) => {
  e.preventDefault();
  loginModal.style.display = "none";
  signupModal.style.display = "flex";
});
// Sample data store (simulate backend)
let flights = [
  {
    id: 'FL001',
    from: 'New York',
    to: 'Tokyo',
    depart: '2025-12-10',
    return: '2025-12-20',
    class: 'Economy',
    price: 750,
  },
  {
    id: 'FL002',
    from: 'Dubai',
    to: 'London',
    depart: '2025-12-15',
    return: '2025-12-25',
    class: 'Business',
    price: 1200,
  }
];

let bookings = [
  {
    bookingId: 'BK1001',
    flightId: 'FL001',
    passengerName: 'Alice Johnson',
    passengersCount: 2,
    status: 'Confirmed'
  }
];

// Admin dashboard elements
const flightsTableBody = document.querySelector('#flightsTable tbody');
const bookingsTableBody = document.querySelector('#bookingsTable tbody');
const totalFlightsEl = document.getElementById('totalFlights');
const totalBookingsEl = document.getElementById('totalBookings');
const btnAddFlight = document.getElementById('btnAddFlight');

// Render functions
function renderFlightsTable() {
  flightsTableBody.innerHTML = '';
  flights.forEach(flight => {
    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td>${flight.id}</td>
      <td>${flight.from}</td>
      <td>${flight.to}</td>
      <td>${flight.depart}</td>
      <td>${flight.return || '-'}</td>
      <td>${flight.class}</td>
      <td>$${flight.price}</td>
      <td>
        <button class="btn-edit" data-id="${flight.id}">Edit</button>
        <button class="btn-delete" data-id="${flight.id}">Delete</button>
      </td>
    `;
    flightsTableBody.appendChild(tr);
  });
  updateStats();
}

function renderBookingsTable() {
  bookingsTableBody.innerHTML = '';
  if (bookings.length === 0) {
    bookingsTableBody.innerHTML = `<tr><td colspan="5">No bookings available.</td></tr>`;
    return;
  }
  bookings.forEach(bk => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${bk.bookingId}</td>
      <td>${bk.flightId}</td>
      <td>${bk.passengerName}</td>
      <td>${bk.passengersCount}</td>
      <td>${bk.status}</td>
    `;
    bookingsTableBody.appendChild(tr);
  });
  updateStats();
}

function updateStats() {
  totalFlightsEl.textContent = flights.length;
  totalBookingsEl.textContent = bookings.length;
}

// Add Flight handler (simplified prompt form)
btnAddFlight.addEventListener('click', () => {
  const id = prompt('Enter Flight No. (e.g. FL003)');
  if (!id) return alert('Flight No. is required!');
  const from = prompt('From (City)');
  if (!from) return alert('From city is required!');
  const to = prompt('To (City)');
  if (!to) return alert('To city is required!');
  const depart = prompt('Departure Date (YYYY-MM-DD)');
  if (!depart) return alert('Departure date is required!');
  const ret = prompt('Return Date (YYYY-MM-DD or leave blank)');
  const cls = prompt('Class (Economy, Business, First Class)');
  const price = prompt('Price (USD)');
  if (isNaN(price) || !price) return alert('Valid price is required!');

  flights.push({
    id,
    from,
    to,
    depart,
    return: ret || '',
    class: cls || 'Economy',
    price: Number(price),
  });
  renderFlightsTable();
});

// Delegate edit/delete buttons using event delegation
flightsTableBody.addEventListener('click', (e) => {
  if (e.target.classList.contains('btn-delete')) {
    const id = e.target.dataset.id;
    if (confirm(`Delete flight ${id}?`)) {
      flights = flights.filter(f => f.id !== id);
      renderFlightsTable();
    }
  }
  else if (e.target.classList.contains('btn-edit')) {
    const id = e.target.dataset.id;
    const flight = flights.find(f => f.id === id);
    if (!flight) return alert('Flight not found.');

    const newFrom = prompt('Edit From:', flight.from);
    const newTo = prompt('Edit To:', flight.to);
    const newDepart = prompt('Edit Departure Date:', flight.depart);
    const newReturn = prompt('Edit Return Date:', flight.return);
    const newClass = prompt('Edit Class:', flight.class);
    const newPrice = prompt('Edit Price:', flight.price);

    flight.from = newFrom || flight.from;
    flight.to = newTo || flight.to;
    flight.depart = newDepart || flight.depart;
    flight.return = newReturn || flight.return;
    flight.class = newClass || flight.class;
    flight.price = Number(newPrice) || flight.price;

    renderFlightsTable();
  }
});

// Initial render of admin dashboard tables on switch to admin view
function renderAdminDashboard() {
  renderFlightsTable();
  renderBookingsTable();
}

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', e => {
    const view = link.dataset.view;
    if (view === 'admin') {
      renderAdminDashboard();
    }
  });
});
// Close modal on outside click
window.addEventListener("click", (e) => {
  if (e.target === loginModal) loginModal.style.display = "none";
  if (e.target === signupModal) signupModal.style.display = "none";
});

// Search flights dummy
document.getElementById("searchForm").addEventListener("submit", e => {
  e.preventDefault();
  alert("Searching flights... This is a front-end demo only.");
});
